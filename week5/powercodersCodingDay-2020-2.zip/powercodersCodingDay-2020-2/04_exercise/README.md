Create an object called books in JavaScript. It should contain names of books for sale, information if the book has been sold or not, and the price of the book. Add 3 books to the object. Show the elements of this object listed alphabetically in the HTML, and add a way for the user to add books. Style the HTML using CSS flex.

Estimated time: 45 minutes <br>
Total points: 45
