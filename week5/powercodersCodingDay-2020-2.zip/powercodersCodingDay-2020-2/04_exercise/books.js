function books(bookName, sold, price){
    this.bookName=bookName;
    this.sold=sold;
    this.price=price;
  this.printBooks =function(){
    console.log(this.bookName+',' + this.sold, + ',' +this.price);
}
};

var book1=new.books('how to heal your life', 'yes', 15);
var book2=new.books('things fall apart', 'no', 20);
var book3=new.books('Pride and prejudice', 'yes', 22);

var listOfBooks =[];
listOfBooks.push(book1, book2, book3);
for(var i=0; i<listOfBooks.length; i++){
    
  for(item in listOfBooks[i]){
    listOfBooks.sort();
      document.write(listOfBooks[i][item]);
  } 
}
