var weekNumbers= [1, 2, 3, 4, 5, 6, 7];
weekNumberstoWords(weekNumbers)
var x = prompt ('Please a number representing the day of the week');
function weekNumberstoWords(params){
    // var x = prompt ('Please a number representing the day of the week');
    if (x=1)
    {
        console.log ('Monday');
    }
    if (x=2)
    {
        console.log ('Tuesday');
    }
    if (x=3)
    {
        console.log ('Wednesday');
    }
    if (x=4)
    {
        console.log ('Thursday');
    }
    if (x=5)
    {
        console.log ('Friday');
    }
    if (x=6)
    {
        console.log ('Saturday');
    }
    if (x=5)
    {
        console.log ('Sunday');
    }
    else
    {return 'not a valid day of the week'}
}