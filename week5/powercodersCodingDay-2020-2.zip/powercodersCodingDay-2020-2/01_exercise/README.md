Change the styles in the css file, so that the robot gets whole and looks like in the final PDF.

Estimated time: 15 minutes <br>
Total points: 15
