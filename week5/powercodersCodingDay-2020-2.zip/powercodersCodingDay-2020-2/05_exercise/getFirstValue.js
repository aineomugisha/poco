var x = [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']; 
getFirstValue(x);

function getFirstValue(params) {
//   for (i=0; i<params.length; i++) {
   x.sort()
   console.log(x[x.length - 1]);
  }
