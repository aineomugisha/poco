# Powercoders Coding Day
Coding Day 2020-2 / Powercoders ZRH bootcamp

1. Fork the powercoders/coding_day repo from Github

   **Make sure you forked it! Do not overwrite the orginal repo.**

2. Pull the forked repo to a local coding_day repo

3. Read every exercise's README carefully, before you start coding.

4. Best to read the first 7 exercises first and check the estimated times, before you start.

4. Exercise 8 is group work in the afternoon

5. Commit every exercise to your local repo, **NOT** Github.


**At the end of the coding day at 3.45pm sharp push your whole repo to Github and upload it as a zip to the Google Classroom assignment. Please include your name in the repo name.**


Morning points: 195 <br>
Afternoon points: 280 <br>
**Total points: 475**
