Write a function that returns the GCD (greatest common divisor) of 3 integers. 

Example: <br>
Input: 16, 24, 64 <br>
Output: 8

Estimated time: 15 minutes <br>
Total points: 15
