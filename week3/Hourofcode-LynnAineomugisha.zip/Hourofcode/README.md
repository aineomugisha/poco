Update the HTML and CSS files so that 
1. the HTML is semantic - what about the divs (5 min)
2. no classes are needed for the css (10 min)
3. the page looks like the final pdfs mobile and desktop (45 min)

Estimated time: 60 minutes
Total points: 60