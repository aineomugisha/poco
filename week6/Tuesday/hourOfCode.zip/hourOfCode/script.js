function gradient1(color1, color2)
{
   
    color1=document.querySelector('#color1').Value;
    color2=document.querySelector('#color2').value;
    document.write(color1);
    document.write(color2);

//   document.getElementsByTagName('body').style.backgroundlinearGradient=color1, color2;

  document.getElementsByTagName('body').style.backgroundImage.linearGradient(color1, color2)
}